// =====================================================
// CONFIGURAÇÃO FIREBASE – Catálogo de Flores e Plantas
// =====================================================

import { initializeApp, FirebaseApp, getApps } from 'firebase/app';
import {
  getFirestore,
  Firestore,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  deleteDoc,
  onSnapshot,
  Unsubscribe,
  DocumentData,
  QuerySnapshot,
} from 'firebase/firestore';

// ─── Credenciais do projeto Firebase ───────────────────────────────────────
const firebaseConfig = {
  apiKey:            "AIzaSyBJJ9E0_NvOihd2nKIClRzcmpvndeK6L2o",
  authDomain:        "catalog-82ce0.firebaseapp.com",
  projectId:         "catalog-82ce0",
  storageBucket:     "catalog-82ce0.firebasestorage.app",
  messagingSenderId: "494897729548",
  appId:             "1:494897729548:web:58ccf777ea558d02e8de29",
};

export const FIREBASE_ENABLED = true;

// ─── Inicialização segura (evita duplicação em HMR) ─────────────────────────
let app: FirebaseApp;
let db: Firestore;

try {
  if (getApps().length === 0) {
    app = initializeApp(firebaseConfig);
  } else {
    app = getApps()[0];
  }
  db = getFirestore(app);
  console.log('[Firebase] ✅ Inicializado — projeto:', firebaseConfig.projectId);
} catch (e) {
  console.error('[Firebase] ❌ Falha na inicialização:', e);
}

// ─── Coleções ──────────────────────────────────────────────────────────────
export const COLLECTIONS = {
  PRODUCTS : 'produtos',
  USERS    : 'usuarios',
  ORDERS   : 'pedidos',
  SETTINGS : 'configuracoes',
} as const;

// ─── CRUD helpers ──────────────────────────────────────────────────────────

/** Salva / atualiza um documento completo (setDoc sem merge para evitar dados parciais) */
export async function fbSet(col: string, id: string, data: object): Promise<boolean> {
  try {
    await setDoc(doc(db, col, id), data);
    return true;
  } catch (e) {
    console.error('[Firebase] fbSet error:', col, id, e);
    return false;
  }
}

/** Merge parcial — usado apenas para campos específicos */
export async function fbMerge(col: string, id: string, data: object): Promise<boolean> {
  try {
    await setDoc(doc(db, col, id), data, { merge: true });
    return true;
  } catch (e) {
    console.error('[Firebase] fbMerge error:', col, id, e);
    return false;
  }
}

/** Lê um único documento */
export async function fbGet<T>(col: string, id: string): Promise<T | null> {
  try {
    const snap = await getDoc(doc(db, col, id));
    return snap.exists() ? (snap.data() as T) : null;
  } catch (e) {
    console.error('[Firebase] fbGet error:', e);
    return null;
  }
}

/** Lista todos os documentos de uma coleção */
export async function fbGetAll<T>(col: string): Promise<T[]> {
  try {
    const snap = await getDocs(collection(db, col));
    return snap.docs.map(d => d.data() as T);
  } catch (e) {
    console.error('[Firebase] fbGetAll error:', e);
    return [];
  }
}

/** Exclui um documento */
export async function fbDelete(col: string, id: string): Promise<boolean> {
  try {
    await deleteDoc(doc(db, col, id));
    return true;
  } catch (e) {
    console.error('[Firebase] fbDelete error:', e);
    return false;
  }
}

/**
 * Escuta mudanças em tempo real numa coleção.
 * O callback sempre recebe o array completo de documentos.
 */
export function fbListen<T>(
  col: string,
  callback: (items: T[]) => void,
): Unsubscribe {
  try {
    return onSnapshot(
      collection(db, col),
      (snap: QuerySnapshot<DocumentData>) => {
        try {
          const items = snap.docs.map(d => d.data() as T);
          callback(items);
        } catch (e) {
          console.error('[Firebase] fbListen callback error:', col, e);
        }
      },
      (error) => {
        console.error('[Firebase] fbListen error:', col, error);
      }
    );
  } catch (e) {
    console.error('[Firebase] fbListen setup error:', col, e);
    return () => {};
  }
}

export { db };
