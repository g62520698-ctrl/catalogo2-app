import { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[ErrorBoundary] Caught error:', error, info.componentStack);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError) {
      return this.props.fallback ?? (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 px-6">
          <div className="bg-white rounded-3xl p-8 shadow-xl max-w-sm w-full text-center">
            <div className="text-6xl mb-4">🌸</div>
            <h2 className="text-xl font-bold text-gray-800 mb-2">Algo deu errado</h2>
            <p className="text-gray-500 text-sm mb-2">
              {this.state.error?.message || 'Erro inesperado no aplicativo.'}
            </p>
            <p className="text-gray-400 text-xs mb-6">
              Os dados estão seguros. Recarregue o aplicativo.
            </p>
            <div className="flex flex-col gap-3">
              <button
                onClick={this.handleReset}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl transition-colors"
              >
                🔄 Tentar novamente
              </button>
              <button
                onClick={() => window.location.reload()}
                className="w-full py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-2xl transition-colors"
              >
                Recarregar página
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
